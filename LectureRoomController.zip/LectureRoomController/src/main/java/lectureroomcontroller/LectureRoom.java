/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package lectureroomcontroller;

/**
 *
 * @author kamel_soft
 */
public class LectureRoom {
 private int numStudents;
    private boolean[] lights;

    public LectureRoom(int maxStudents) {
        numStudents = 0;
        lights = new boolean[3]; // Assuming 3 lights
    }

    public void addStudents(int numToAdd) {
        numStudents += numToAdd;
        if (numStudents > 0) {
            System.out.println("Number of students in the room: " + numStudents);
        } else {
            System.out.println("The room is empty.");
        }
    }

    public void removeStudents(int numToRemove) {
        numStudents -= numToRemove;
        if (numStudents < 0) {
            numStudents = 0;
        }
        System.out.println("Number of students in the room: " + numStudents);
    }

    public void turnOnLight(int lightNum) {
        if (isValidLightNumber(lightNum)) {
            lights[lightNum - 1] = true;
            System.out.println("Light " + lightNum + " turned on.");
        } else {
            System.out.println("Invalid light number.");
        }
    }

    public void turnOffLight(int lightNum) {
        if (isValidLightNumber(lightNum)) {
            lights[lightNum - 1] = false;
            System.out.println("Light " + lightNum + " turned off.");
        } else {
            System.out.println("Invalid light number.");
        }
    }

    private boolean isValidLightNumber(int lightNum) {
        return lightNum >= 1 && lightNum <= lights.length;
    }
}

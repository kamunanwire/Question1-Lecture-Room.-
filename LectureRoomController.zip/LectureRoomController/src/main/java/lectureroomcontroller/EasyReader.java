package lectureroomcontroller;

import java.util.Scanner;

/**
 *
 * @author kamel_soft
 */
public class EasyReader {
    private Scanner scanner;

    public EasyReader() {
        scanner = new Scanner(System.in);
    }

    public int readInt() {
        int value = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        return value;
    }

    public char readChar() {
        String input = scanner.nextLine();
        return input.length() > 0 ? input.charAt(0) : '\0';
    }

    public String readString() {
        return scanner.nextLine();
    }

    public String nextLine() {
        return scanner.nextLine();
    }
}

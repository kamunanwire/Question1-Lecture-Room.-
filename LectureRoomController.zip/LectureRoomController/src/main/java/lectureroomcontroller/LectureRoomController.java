package lectureroomcontroller;

/**
 *
 * @author kamel_soft
 */
public class LectureRoomController {
    public static void main(String[] args) {
        LectureRoom room = new LectureRoom(100); 
        EasyReader reader = new EasyReader();

        while (true) {
            System.out.println("Menu:");
            System.out.println("W: Add students");
            System.out.println("X: Remove students");
            System.out.println("Y: Turn on light");
            System.out.println("Z: Turn off light");
            System.out.println("Q: Quit");

            char choice = reader.readChar();

            switch (choice) {
                case 'W':
                    System.out.print("Enter number of students to add: ");
                    int numToAdd = reader.readInt();
                    room.addStudents(numToAdd);
                    break;
                case 'X':
                    System.out.print("Enter number of students to remove: ");
                    int numToRemove = reader.readInt();
                    room.removeStudents(numToRemove);
                    break;
                case 'Y':
                    System.out.print("Enter light number to turn on (1-3): ");
                    int lightNum = reader.readInt();
                    room.turnOnLight(lightNum);
                    break;
                case 'Z':
                    System.out.print("Enter light number to turn off (1-3): ");
                    int lightNumOff = reader.readInt();
                    room.turnOffLight(lightNumOff);
                    break;
                case 'Q':
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
